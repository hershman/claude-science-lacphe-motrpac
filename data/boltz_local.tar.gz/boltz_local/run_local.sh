#!/bin/bash
# Run all complexes on the Apple-Silicon GPU. Activate the env first:
#   conda activate boltz-mps
set -e
export PYTORCH_ENABLE_MPS_FALLBACK=1   # ops without an MPS kernel fall back to CPU
export KMP_DUPLICATE_LIB_OK=TRUE
mkdir -p msa out

if [ ! -f msa/HCAR1.a3m ]; then
  echo "== MSA for HCAR1 (once, via server) =="
  boltz predict seed_HCAR1.yaml --use_msa_server --out_dir seedout_HCAR1 \
      --output_format pdb --diffusion_samples 1 --recycling_steps 1 \
      --accelerator mps --no_kernels || true
  A3M=$(find seedout_HCAR1 -name '*.a3m' | head -1)
  [ -n "$A3M" ] && cp "$A3M" msa/HCAR1.a3m && echo "cached msa/HCAR1.a3m"
fi
if [ ! -f msa/MRGPRD.a3m ]; then
  echo "== MSA for MRGPRD (once, via server) =="
  boltz predict seed_MRGPRD.yaml --use_msa_server --out_dir seedout_MRGPRD \
      --output_format pdb --diffusion_samples 1 --recycling_steps 1 \
      --accelerator mps --no_kernels || true
  A3M=$(find seedout_MRGPRD -name '*.a3m' | head -1)
  [ -n "$A3M" ] && cp "$A3M" msa/MRGPRD.a3m && echo "cached msa/MRGPRD.a3m"
fi
echo "== co-fold + affinity =="
n=0; tot=$(ls yaml/*.yaml | wc -l | tr -d ' ')
for y in yaml/*.yaml; do
  n=$((n+1)); bn=$(basename "$y" .yaml)
  boltz predict "$y" --out_dir out --output_format pdb \
     --recycling_steps 3 --diffusion_samples 3 \
     --accelerator mps --no_kernels >/dev/null 2>&1 || echo "FAILED: $bn"
  echo "...$n/$tot ($bn)"
done
echo "== DONE. Point Claude Science at:  $(pwd)/out =="
