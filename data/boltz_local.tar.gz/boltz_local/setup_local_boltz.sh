#!/bin/bash
# One-time: install Boltz-2 with Apple-Silicon (MPS) support into ./boltz-env
set -e
if ! command -v conda >/dev/null; then
  echo "conda not found. Install Miniforge first: https://github.com/conda-forge/miniforge"; exit 1
fi
conda create -y -n boltz-mps python=3.11
eval "$(conda shell.bash hook)"; conda activate boltz-mps
pip install --upgrade pip
# Boltz mainline is CUDA-first; MPS support lives in PR #527. Check it out by number.
rm -rf boltz-src
git clone https://github.com/jwohlwend/boltz.git boltz-src
cd boltz-src
git fetch origin pull/527/head:mps-support
git checkout mps-support
pip install -e .
echo "OK: 'conda activate boltz-mps' then run ./run_local.sh"
